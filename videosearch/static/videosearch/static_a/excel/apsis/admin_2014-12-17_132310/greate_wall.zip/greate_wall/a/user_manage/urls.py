from django.conf.urls import patterns, url
from a.user_manage import views

urlpatterns = patterns('a.user_manage.views',
                       url(r'^$', views.self, name='self'),
                       url(r'^modify$', views.modify, name='modify'),
                       # url(r'^self$', views.self, name='self'),
                       # url(r'^result$', views.result, name='result'),
                       # url(r'^check$', views.check, name='check'),
)