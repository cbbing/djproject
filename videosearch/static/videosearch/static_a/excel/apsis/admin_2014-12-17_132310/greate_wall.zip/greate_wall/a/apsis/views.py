__author__ = 'Chris'
# coding=utf-8
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import Template, Context, RequestContext
from django.template.loader import get_template
from dao import get_apsis_api_send_flag_info_list, get_apsis_rsv_send_flag_info_list, get_apsis_api_psr_data_item, \
    get_apsis_api_psr_info_list, datetime2string
from util import get_current_platform
from django.contrib.auth.decorators import login_required


@login_required
def self(request):
    return HttpResponseRedirect("/apsis/apsis_index")


@login_required
def apsis_index(request):
    t = get_template("a/apsis/apsis_index.html")
    apsis_api_send_flag_list = get_apsis_api_send_flag_info_list()
    apsis_rsv_send_flag_list = get_apsis_rsv_send_flag_info_list()
    result = [apsis_api_send_flag_list, apsis_rsv_send_flag_list]
    html = t.render(Context({'obj_list': result,
                             'apsis_api_send_flag_list': apsis_api_send_flag_list,
                             'apsis_rsv_send_flag_list': apsis_rsv_send_flag_list}))
    return HttpResponse(html)


@login_required
def apsis_query(request):
    return render_to_response("a/apsis/apsis_query.html", RequestContext(request))


@login_required
def apsis_query_quick(request):
    os_platform = get_current_platform()
    if request.POST['cert_no_list']:
        cert_no = request.POST['cert_no_list']
        # info_list = get_apsis_api_psr_info_list("522229199408280084")
        # cert_no may be numbers
        info_list = get_apsis_api_psr_info_list(str(cert_no))
        data_item_list = get_apsis_api_psr_data_item()
        info_list_less = []
        data_item_list_less = []
        for item in info_list:
            tmp = []
            for i in xrange(0, len(item)):
                if i in (0, 2, 3, 4, 6, 9, 10, 16, 17, 18, 20, 22, 26):
                    if i in (6, 22,) and item[i]:
                        tmp.append(datetime2string(item[i], "%Y-%m-%d"))
                    elif i == 17 and item[i]:
                        if os_platform == 'Windows':
                            tmp.append(item[i].decode('gbk'))
                        else:
                            tmp.append(item[i].decode('utf8'))
                    elif i in (0, 2,):
                        try:
                            tmp.append(int(item[i]))
                        except:
                            tmp.append('')
                    elif not item[i]:
                        tmp.append('')
                    else:
                        tmp.append(item[i])
            info_list_less.append(tmp)

        # for i in xrange(0, len(data_item_list)):
        # if i in (0, 2, 3, 4, 6, 9, 10, 16, 17, 18, 20, 22):
        # data_item_list_less.append(data_item_list[i])
        data_item_list_less = ['ID', '航班ID', '航空公司', '航班号', '航班日期', '出发机场',
                               '到达机场', '姓名', '中文名', '姓', '名', '出生日期', '证件号码']

        return render_to_response("a/apsis/apsis_query_quick.html",
                                  {"info_list": info_list_less, "dataitem": data_item_list_less})
    else:
        return HttpResponseRedirect("/apsis/apsis_query")

        # if ("username" in request.COOKIES):
        # return render_to_response("a/apsis/apsis_query.html", RequestContext(request))
        # else:
        # return render_to_response("a/auth_manage/auth.html", RequestContext(request))

