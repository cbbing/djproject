# from django.contrib import admin
# from a.general_info.models import basic_info, baby_info
#
#
# class basic_data_info_admin(admin.ModelAdmin):
#     list_display = ('seq_id',
#                     'team_no',
#                     'job_no',
#                     'name',
#
#                     'tel',
#                     'mobile',
#                     'email',
#
#                     'pol_exp',
#                     'birth_gre',
#                     'birth_lun',
#
#                     'cert_no',
#                     'education',
#                     'department',
#                     'team',
#                     'duties',
#                     'nation',
#                     'birth_place',
#
#                     'in_party_time',
#                     'in_working_time',
#                     'is_regular_party_member',
#                     'is_document_managed_by_firm',
#                     'duties_in_party',
#                     'working_place',
#
#                     'femail_help_fund',
#                     'is_married',
#                     'sex')
#     search_fields = ('job_no', 'name', 'email', 'birth_gre', 'tel', 'mobile')
#     list_filter = ('birth_gre',)
#     # date_hierarchy = 'birth_gre'
#     ordering = ('team_no',)
#     save_as = True
#     #filter_horizontal = ('authors',)
#     #raw_id_fields = ('name',)
#
#
# class baby_data_info_admin(admin.ModelAdmin):
#     list_display = ('job_no',
#                     'name',
#                     'baby_name',
#                     'baby_sex',
#                     'baby_birty',
#                     'comment',
#                     'exp')
#     search_fields = ('job_no',
#                      'name',
#                      'baby_name',
#                      'baby_sex',
#                      'baby_birty',
#                      'comment',
#                      'exp')
#     list_filter = ('baby_birty',)
#     # date_hierarchy = 'birth_gre'
#     ordering = ('job_no',)
#     save_as = True
#     #filter_horizontal = ('authors',)
#     #raw_id_fields = ('name',)
#
#
# # Register your models here.
# admin.site.register(basic_info, basic_data_info_admin)
# admin.site.register(baby_info, baby_data_info_admin)
