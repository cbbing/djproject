from django.conf.urls import patterns, url
from a.guide import views

urlpatterns = patterns('a.guide.views',
                       url(r'^$', views.self, name='self'),
                       # url(r'^self$', views.self, name='self'),
                       # url(r'^result$', views.result, name='result'),
                       # url(r'^check$', views.check, name='check'),
)