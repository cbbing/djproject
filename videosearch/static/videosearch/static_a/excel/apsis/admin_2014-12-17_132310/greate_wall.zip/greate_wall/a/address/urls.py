from django.conf.urls import patterns, url
from a.address import views

urlpatterns = patterns('a.address.views',
                       url(r'^$', views.self, name='self'),
                       url(r'^self$', views.self, name='self'),
)