__author__ = 'Chris'
# coding=utf-8
import cx_Oracle
import string
import xlwt
import xlrd
from xlutils.copy import copy
import datetime
import time



def datetime_toString(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def string2datetime(dt_str):
    try:
        # datetime.date(y, m, d)
        datetime.strptime(dt_str, "%Y-%m-%d")
        #print "Date format is True"
        return True
    except:
        # print "Date format is False"
        return False


# 2014-03-02
def isToday(datestr):
    if time.strftime("%Y-%m-%d", time.localtime(time.time())) == datestr:
        return True
    else:
        return False


def getRowAndColume(filename):
    data = xlrd.open_workbook(filename)
    table = data.sheets()[0]
    nrows = table.nrows
    ncols = table.ncols

    lengthList = []
    lengthList.append(nrows)
    lengthList.append(ncols)
    return lengthList