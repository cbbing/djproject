__author__ = 'Chris'
# encoding = utf8

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import *
from sqlalchemy.schema import *
from sqlalchemy import text

# engine = create_engine('oracle+cx_oracle://apsis:apsis@10.6.184.74:1521/APSISAPI', echo=True)
#
# Session = sessionmaker(bind=engine)
# session = Session()
#
# meta = MetaData()
#
# apsis_order_user_tab = Table("apsis_order_user_tab", meta, autoload=True, autoload_with=engine)
# apsis_send_flag_tab = Table("apsis_send_flag_tab", meta, autoload=True, autoload_with=engine)
#
# result = session.query(apsis_order_user_tab, apsis_send_flag_tab).join(apsis_send_flag_tab,
# apsis_order_user_tab.c.send_queue == apsis_send_flag_tab.c.send_queue).all()
#
# for item in result:
# print item
#
# session.close()

def get_engine(DB_NAME):
    if DB_NAME == 'APSISAPI':
        return create_engine('oracle+cx_oracle://apsis:apsis@10.6.184.74:1521/APSISAPI', echo=True)
    if DB_NAME == 'APSISRSV':
        return create_engine('oracle+cx_oracle://apsisrsv:apsisrsv@10.6.184.75:1523/APSISRSV', echo=True)


def get_apsis_api_send_flag_info():
    engine = get_engine('APSISAPI')
    Session = sessionmaker(bind=engine)
    session = Session()
    meta = MetaData()
    apsis_send_flag_tab = Table("apsis_send_flag_tab", meta, autoload=True, autoload_with=engine)

    result = session.query(apsis_send_flag_tab).all()

    result_list = []
    count = 1

    for item in result:
        result_item = {}
        result_item['ID'] = count
        result_item['MSG_TYPE'] = item[0]
        result_item['SEND_QUEUE'] = item[1]
        result_item['MIN_FLT_ID'] = item[2]
        result_item['MIN_SN_ID'] = item[3]
        result_item['UPDATE_FLT_ID_TIME'] = datetime2string(item[4])
        result_item['UPDATE_SN_ID_TIME'] = datetime2string(item[5])
        result_list.append(result_item)
        count += 1

    return result_list


def get_apsis_api_send_flag_info_list():
    engine = get_engine('APSISAPI')
    Session = sessionmaker(bind=engine)
    session = Session()
    meta = MetaData()
    apsis_send_flag_tab = Table("apsis_send_flag_tab", meta, autoload=True, autoload_with=engine)

    # result = session.query(apsis_send_flag_tab).order_by(apsis_send_flag_tab.c.keys()[-1]).all()
    result = session.query(apsis_send_flag_tab).order_by(text("UPDATE_SN_ID_TIME desc")).all()

    result_list = []
    count = 1

    for item in result:
        list_item = []
        list_item.append(count)
        list_item.append(item[0])
        list_item.append(item[1])
        list_item.append(int(item[2]))
        list_item.append(int(item[3]))
        list_item.append(datetime2string(item[4]))
        list_item.append(datetime2string(item[5]))
        result_list.append(list_item)
        count += 1

    return result_list


def get_apsis_rsv_send_flag_info_list():
    engine = get_engine('APSISAPI')
    Session = sessionmaker(bind=engine)
    session = Session()
    meta = MetaData()
    apsis_send_flag_tab = Table("ref_import_flag_tab", meta, autoload=True, autoload_with=engine)

    # result = session.query(apsis_send_flag_tab).order_by(apsis_send_flag_tab.c.keys()[-1]).all()
    result = session.query(apsis_send_flag_tab).order_by(text("UPDATE_TIME desc")).all()

    result_list = []
    count = 1

    for item in result:
        list_item = []
        list_item.append(count)
        list_item.append(item[0])
        list_item.append(datetime2string(item[1]))
        list_item.append(item[2])
        list_item.append(datetime2string(item[3]))
        result_list.append(list_item)
        count += 1

    return result_list


def get_apsis_api_psr_info_list(para_cert_no):
    engine = get_engine('APSISAPI')
    Session = sessionmaker(bind=engine)
    session = Session()
    meta = MetaData()
    passenger_info_his_tab = Table("passenger_info_his_tab", meta, autoload=True, autoload_with=engine)

    result = session.query(passenger_info_his_tab).filter(text("cert_no=:cert_nbr")).params(cert_nbr=para_cert_no).all()

    print result

    return result


def get_apsis_api_psr_data_item():
    return ['sn_id',
            'border_type',
            'seg_fltid',
            'flt_airlcode',
            'flt_number',
            'flt_suffix',
            'flt_date',
            'seg_deptno',
            'seg_destno',
            'seg_dept_code',
            'seg_dest_code',
            'sta_depttm',
            'sta_arvetm',
            'pdt_dept',
            'pdt_dest',
            'psr_hostnbr',
            'psr_name',
            'psr_chnname',
            'pdt_lastname',
            'pdt_midname',
            'pdt_firstname',
            'psr_status',
            'pdt_birthday',
            'pdt_bir_adress',
            'psr_gender',
            'cert_type',
            'cert_no',
            'pdt_exprirydate',
            'pdt_issuedate',
            'pdt_issue_countryA',
            'pdt_country',
            'psr_type',
            'psr_brdno',
            'psr_group',
            'psr_ics',
            'psr_crs',
            'psr_seatnbr',
            'psr_fffr',
            'psr_efmn',
            'psr_bags',
            'psr_bagwgt',
            'psr_class',
            'psr_ckipid',
            'psr_office',
            'psr_agent',
            'psr_ckitime',
            'psr_sip',
            'psr_foid_nonet',
            'psr_seg_seatnbrAS',
            'ffqno',
            'datasource',
            'telno',
            'paxclass',
            'adress',
            'city',
            'province',
            'icao_code',
            'postcode',
            'edi',
            'sby',
            'psr_inf',
            'psr_infname',
            'stcr',
            'wl',
            'jmp',
            'special_seat',
            'special_bg',
            'svc',
            'cki_chg',
            'cmt',
            'vip',
            'ures',
            'psr_sbyno',
            'psr_stdrs',
            'psr_acc',
            'psr_spml_id',
            'psr_spml',
            'psr_msg',
            'psr_psm',
            'psr_pil',
            'psr_pctc',
            'psr_pspt',
            'psr_notify',
            'psr_blnd',
            'psr_deaf',
            'psr_emig',
            'psr_inad',
            'psr_wtype',
            'psr_wcbd',
            'psr_wcbw',
            'psr_wcmd',
            'psr_wcob',
            'psr_ctca',
            'psr_rush',
            'psr_hbprbg',
            'psr_avih',
            'psr_petc',
            'psr_baggage',
            'psr_unattach',
            'psr_arst',
            'psr_xasr',
            'psr_xabp',
            'psr_exstseat',
            'psr_rst',
            'psr_spe',
            'psr_asoboi',
            'psr_osr',
            'psr_aec',
            'psr_sea',
            'psr_rea',
            'psr_bsct',
            'psr_udgrade',
            'psr_ofl',
            'psr_dep',
            'psr_rtfi',
            'psr_rffi',
            'psr_tsi',
            'psr_xres',
            'psr_xt',
            'psr_citycanc',
            'psr_vudgrade',
            'psr_edi_warn',
            'psr_inbound',
            'psr_edii',
            'psr_outbound',
            'psr_edio',
            'psr_edi_dept',
            'psr_edi_dest',
            'pnr_ref',
            'delete_flag',
            'delete_flt_id',
            'psr_arrive_time']


def datetime2string(dt, fmt="%Y-%m-%d %H:%M:%S"):
    return dt.strftime(fmt)


def test():
    info_list = get_apsis_api_psr_info_list(str(522229199408280084))
    data_item_list = get_apsis_api_psr_data_item()
    info_list_less = []
    data_item_list_less = []
    for item in info_list:
        tmp = []
        for i in xrange(0, len(item)):
            if i in (0, 2, 3, 4, 6, 9, 10, 16, 17, 18, 19, 20, 21, 22):
                if i == 17:
                    tmp.append(item[i].decode('gbk'))
                    print item[i]
                else:
                    tmp.append(item[i])
        info_list_less.append(tmp)

    for i in xrange(0, len(data_item_list)):
        if i in (0, 2, 3, 4, 6, 9, 10, 16, 17, 18, 19, 20, 21, 22):
            data_item_list_less.append(data_item_list[i])


if __name__ == '__main__':
    # result_list = get_apsis_api_send_flag_info_list()
    # print int(result_list[0][3]), type(result_list[0][3])

    # result_list = get_apsis_api_psr_info_list('522229199408280084')
    # for item in result_list:
    # print item
    test()






