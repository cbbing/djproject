__author__ = 'Chris'
# coding=utf-8
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import Template, Context, RequestContext
from greate_wall.settings import STATICFILES_DIR_a
from a.models import basic_info, basic_info_seq
import os
import excelmaker
from django.contrib.auth.decorators import login_required
# Create your views here.


@login_required
def self(request):
    return HttpResponseRedirect("/general_info/address_page")


@login_required
def select2select(request):
    # return django.template.RequestContext('templates_a/login.html')
    return render_to_response('a/general_info/select2select.html', context_instance=RequestContext(request))


@login_required
def selectProcess(request):
    # return django.template.RequestContext('templates_a/login.html')

    if 'dataItemList' in request.GET:
        # 1 remove xls file
        removeFilesInDir(STATICFILES_DIR_a + 'static_a/excel')
        # 2 process data
        message = 'You searched for: /n%s' % request.GET['dataItemList']
        selectItemLst = request.GET['dataItemList'].split(",")
        count = 1
        basic_info_seq.objects.all().update(seq_no=-1)
        for item in selectItemLst:
            basic_info_seq.objects.filter(seq_item=item).update(seq_no=count)
            count += 1
        print selectItemLst
        # 3 create new xls file

    else:
        message = 'You submitted an empty form.'
    print message


#
# def fileCreate(request):
# # return django.template.RequestContext('templates_a/login.html')
# return render_to_response('a/general_info/fileCreate.html', context_instance=RequestContext(request))

def removeFilesInDir(targetDir):
    print targetDir
    for file in os.listdir(targetDir):
        targetFile = os.path.join(targetDir, file)
        if os.path.isfile(targetFile):
            os.remove(targetFile)


@login_required
def address_page(request):
    alldata = basic_info.objects.all()
    allitem = basic_info_seq.objects.order_by("seq_no")

    dataitem = []
    data = []
    datacn = []
    # print len(alldata)
    # print len(allitem)

    for item in alldata:
        alldatadic = {}
        alldatadic['seq_id'] = item.seq_id
        alldatadic['team_no'] = item.team_no
        alldatadic['job_no'] = item.job_no
        alldatadic['name'] = item.name
        alldatadic['tel'] = item.tel
        alldatadic['mobile'] = item.mobile
        alldatadic['email'] = item.email
        alldatadic['pol_exp'] = item.pol_exp
        alldatadic['birth_gre'] = item.birth_gre
        alldatadic['birth_lun'] = item.birth_lun
        alldatadic['cert_no'] = item.cert_no
        alldatadic['education'] = item.education
        alldatadic['department'] = item.department
        alldatadic['team'] = item.team
        alldatadic['duties'] = item.duties
        alldatadic['nation'] = item.nation
        alldatadic['birth_place'] = item.birth_place
        alldatadic['in_party_time'] = item.in_party_time
        alldatadic['in_working_time'] = item.in_working_time
        alldatadic['is_regular_party_member'] = item.is_regular_party_member
        alldatadic['is_document_managed_by_firm'] = item.is_document_managed_by_firm
        alldatadic['duties_in_party'] = item.duties_in_party
        alldatadic['working_place'] = item.working_place
        alldatadic['femail_help_fund'] = item.femail_help_fund
        alldatadic['is_married'] = item.is_married
        alldatadic['sex'] = item.sex
        alldatadic['comment1'] = item.comment1

        data.append(alldatadic)

    for i in xrange(0, len(allitem)):
        if allitem[i].seq_no > 0:
            # print allitem[i].seq_cn
            # print allitem[i].id
            dataitem.append(allitem[i])

    datatarget = []
    for da in data:
        smalldata = []
        for daitem in dataitem:
            smalldata.append(da[daitem.seq_item])
        datatarget.append(smalldata)

    # create excel
    rela_file_name = excelmaker.getCBMSinfo(dataitem, datatarget)

    context = {'data': datatarget, 'dataitem': dataitem, 'rela_file_name': rela_file_name}
    return render_to_response('a/general_info/address_page.html', context_instance=RequestContext(request, context))


def big_file_download(request):
    # do something...

    def readFile(fn, buf_size=262144):
        f = open(fn, "rb")
        while True:
            c = f.read(buf_size)
            if c:
                yield c
            else:
                break
        f.close()

    file_name = "D:/9-workspaces/PycharmProjects/greate_wall/static/static_a/excel/data-2014-12-15_101601.xls"
    file_name1 = "D:/9-workspaces/PycharmProjects/greate_wall/static/static_a/excel/tmp"
    response = HttpResponse(readFile(file_name1))

    return response


def big_file_download1(request):
    file_name = "D:/9-workspaces/PycharmProjects/greate_wall/static/static_a/excel/data-2014-12-15_101601.xls"
    response = HttpResponse(mimetype='application/force-download')
    response['Content-Disposition'] = 'attachment; filename=%s' % file_name
    response['X-Sendfile'] = file_name
    # It's usually a good idea to set the 'Content-Length' header too.
    # You can also set any other required headers: Cache-Control, etc.
    return response


def download3(request):
    file_name = "D:/9-workspaces/PycharmProjects/greate_wall/static/static_a/excel/data-2014-12-15_101601.xls"
    return HttpResponseRedirect(file_name)