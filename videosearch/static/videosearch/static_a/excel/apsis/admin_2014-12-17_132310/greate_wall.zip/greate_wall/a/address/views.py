__author__ = 'Chris'
# coding=utf-8
from django.shortcuts import render_to_response
from django.template import Template, Context, RequestContext
from django.contrib.auth.decorators import login_required
from a.logic_util import get_user_group_context


@login_required
def self(request):
    user_name = request.user.username
    # return render_to_response("a/address/address_book.html", RequestContext(request))

    if user_name:
        context = get_user_group_context(user_name)
        return render_to_response('address_book.html', RequestContext(request, context))
    else:
        return render_to_response('address_book.html', RequestContext(request))
