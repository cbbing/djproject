# coding=utf-8
from django.shortcuts import render_to_response
from django.template import Template, Context, RequestContext
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from a.logic_util import get_user_group_context


@login_required
def self(request):
    user_name = request.user.username

    if user_name:
        context = get_user_group_context(user_name)
        return render_to_response('user_manage.html', RequestContext(request, context))
    else:
        return render_to_response('user_manage.html', RequestContext(request))


@login_required
def modify(request):
    user_name = request.user.username

    if user_name:
        context = get_user_group_context(user_name)
        return render_to_response('user_modify.html', RequestContext(request, context))
    else:
        return render_to_response('user_modify.html', RequestContext(request))
