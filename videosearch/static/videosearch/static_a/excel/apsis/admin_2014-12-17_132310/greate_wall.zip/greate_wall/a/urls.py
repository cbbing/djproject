from a import views
from django.conf.urls import patterns, url, include
from greate_wall import settings
import django.contrib.auth


urlpatterns = patterns('a.views',

                       url(r'^$', views.index, name='index'),
                       url(r'^logout_view', views.logout_view, name='logout_view'),
                       url(r'^index/', views.index, name='index'),
                       url(r'^aboutme', views.aboutme, name='aboutme'),

                       (r'^address/', include('a.address.urls')),
                       (r'^general_info/', include('a.general_info.urls')),
                       (r'^guide/', include('a.guide.urls')),
                       (r'^apsis/', include('a.apsis.urls')),
                       (r'^user_manage/', include('a.user_manage.urls')),
                       (r'^blog/', include('a.blog.urls')),
)

