# from django.db import models
# # -*- coding: utf-8 -*-
#
# class basic_info(models.Model):
#     seq_id = models.IntegerField(blank=True, max_length=60)  # 序列号，用以统计
#     team_no = models.CharField(blank=True, max_length=60)  # 组序号，用以按组排序
#     job_no = models.CharField(null=False, max_length=60)  # 工号
#     name = models.CharField(null=False, max_length=60)  # 姓名
#
#     tel = models.CharField(blank=True, max_length=60)  # 办公电话
#     mobile = models.CharField(blank=True, max_length=60)  # 移动电话
#     email = models.CharField(blank=True, max_length=60)  # 电子邮箱
#
#     pol_exp = models.CharField(blank=True, max_length=60)  # 政治面貌
#     birth_gre = models.DateField(blank=True, max_length=60)  # 阳历生日
#     birth_lun = models.DateField(blank=True, max_length=60)  # 阴历生日
#
#     cert_no = models.CharField(blank=True, max_length=60)  # 身份证号
#     education = models.CharField(blank=True, max_length=60)  # 学历
#     department = models.CharField(blank=True, max_length=60)  # 部门
#     team = models.CharField(blank=True, max_length=60)  # 组
#     duties = models.CharField(blank=True, max_length=60)  # 职务
#     nation = models.CharField(blank=True, max_length=60)  # 民族
#     birth_place = models.CharField(blank=True, max_length=60)  # 籍贯
#
#     in_party_time = models.DateField(blank=True, max_length=60)  # 入党时间
#     in_working_time = models.DateField(blank=True, max_length=60)  # 参加工作时间
#     is_regular_party_member = models.BooleanField(blank=True, max_length=60)  # 是否正式党员
#     is_document_managed_by_firm = models.BooleanField(blank=True, max_length=60)  # 是否为公司直管档案
#     duties_in_party = models.CharField(blank=True, max_length=60)  # 党内职务
#     working_place = models.CharField(blank=True, max_length=60)  # 工作地
#
#     femail_help_fund = models.CharField(blank=True, max_length=60)  # 女职工互助基金
#     is_married = models.BooleanField(blank=True, max_length=60)  # 婚否
#     sex = models.CharField(blank=True, max_length=60)  # 性别
#
#     comment1 = models.CharField(blank=True, max_length=200)  # 备注1
#     comment2 = models.CharField(blank=True, max_length=200)  # 备注2
#
#     exp1 = models.CharField(blank=True, max_length=200)
#     exp2 = models.CharField(blank=True, max_length=200)
#     exp3 = models.CharField(blank=True, max_length=200)
#     exp4 = models.CharField(blank=True, max_length=200)
#     exp5 = models.CharField(blank=True, max_length=200)
#     exp6 = models.CharField(blank=True, max_length=200)
#
#
#     def __unicode__(self):
#         return self.name
#
#
# class basic_info_seq(models.Model):
#     seq_item = models.CharField(blank=False, max_length=60)  # 序列项
#     seq_no = models.IntegerField(blank=True, max_length=60)  # 序列项值，-1表示未选择，大于0的值表示顺序
#     seq_cn = models.CharField(blank=True, max_length=60)  # 序列项中文
#
#     def __unicode__(self):
#         return self.seq_item
#
#     class Meta:
#         ordering = ['seq_no']
#
# class basic_info_cn(models.Model):
#     item = models.CharField(blank=False, max_length=60)  # 序列项
#     cn = models.CharField(blank=True, max_length=60)  # 序列项中文
#     def __unicode__(self):
#         return self.item
#
# class baby_info(models.Model):
#     job_no = models.CharField(null=False, max_length=60)  # 工号
#     name = models.CharField(null=False, max_length=60)  # 姓名
#     baby_name = models.CharField(null=False, max_length=60)  # 子女姓名
#     baby_sex = models.CharField(null=False, max_length=60)  # 子女性别
#     baby_birty = models.DateField(blank=True, max_length=60)  # 子女生日
#
#     comment = models.CharField(blank=True, max_length=200)  # 备注
#     exp = models.CharField(blank=True, max_length=200)  # 扩展
#
#
#     def __unicode__(self):
#         return self.name
