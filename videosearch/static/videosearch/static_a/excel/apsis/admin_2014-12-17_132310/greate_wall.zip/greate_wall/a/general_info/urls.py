from django.conf.urls import patterns, url
from a.general_info import views

urlpatterns = patterns('a.general_info.views',
                       url(r'^$', views.self, name='self'),
                       url(r'^address_page$', views.address_page, name='address_page'),
                       url(r'^select2select', views.select2select, name='select2select'),
                       url(r'^selectProcess', views.selectProcess, name='selectProcess'),
                       url(r'^big_file_download', views.big_file_download, name='big_file_download'),
                       url(r'^big_file_download1', views.big_file_download1, name='big_file_download1'),
                       url(r'^download3', views.download3, name='download3'),


                       # url(r'^self$', views.self, name='self'),
                       # url(r'^result$', views.result, name='result'),
                       # url(r'^check$', views.check, name='check'),
)