__author__ = 'Chris'
from django.contrib.auth.models import User
from a.models import UserAllInfo

def get_user_group_context(user_name):
    user_obj = User.objects.filter(username=user_name).all()[0]
    is_super = user_obj.is_superuser
    uid = user_obj.id

    group_obj = user_obj.groups.all()
    groups = {}
    group_id_list = []
    for grp in group_obj:
        groups["id"] = grp.id
        groups["name"] = grp.name
        group_id_list.append(grp.id)
    context = {'username': user_name, 'group_id_list': group_id_list, 'is_super': is_super}

    return context


def sync_user_all_info(user_id):
    obj = UserAllInfo.objects.filter(uid=user_id).all()
    if len(obj) <= 0:
        new_user_all_info = UserAllInfo(uid=user_id, logo_nm=None, content=None)
        new_user_all_info.save()

def set_user_all_info(user_id, logo_nm, content):
    pass