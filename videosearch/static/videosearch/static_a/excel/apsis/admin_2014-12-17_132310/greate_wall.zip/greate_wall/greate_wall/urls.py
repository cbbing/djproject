from django.conf.urls import patterns, include, url

from django.contrib import admin
from django.conf import settings

admin.autodiscover()

urlpatterns = patterns('',
                       # Examples:
                       # url(r'^$', 'greate_wall.views.home', name='home'),
                       # url(r'^blog/', include('blog.urls')),

                       (r'^admin/', include(admin.site.urls)),
                       (r'^static/(?P<path>.*)$', 'django.views.static.serve',
                        {'document_root': settings.STATICFILES_DIRS}),
                       # {'document_root': settings.STATIC_ROOT}),

                       (r'^', include('a.urls')),
)

urlpatterns += patterns('',
                        url(r'^login/$', 'django.contrib.auth.views.login', {'template_name': 'login.html'}),
)


