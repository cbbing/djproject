__author__ = 'Chris'
# coding=utf-8
import cx_Oracle
import xlwt
import xlrd
from xlutils.copy import copy
import datetime
import time
from greate_wall.settings import STATICFILES_DIR_a
from a.util import get_current_time_str


def hello():
    print "hello world"


def getCBMSinfo(dataitem, datatarget):
    timestr = get_current_time_str()
    rela_file_name = 'static_a/excel/data-%s.xls' % timestr
    filename = STATICFILES_DIR_a + rela_file_name
    firstLineList = []
    for item in dataitem:
        firstLineList.append(item.seq_cn)
    writeToExcelFirstLine(filename, firstLineList)
    writeToExcel(filename, datatarget)

    return '/static/' + rela_file_name


# write psr info per 5000
def writeToExcelFirstLine(filename, firstLineList):
    book = xlwt.Workbook()
    sheet1 = book.add_sheet(u'综合数据')
    # book.add_sheet('word')  #add a

    row1 = sheet1.row(0)
    columnCount = 0

    for item in firstLineList:
        row1.write(columnCount, item)
        columnCount += 1

    for i in range(0, columnCount, 1):
        sheet1.col(i).width = 12000
        # sheet1.col(0).width = 10000

    book.save(filename)


def writeToExcel(filename, psrInfoList):
    rb = xlrd.open_workbook(filename)
    book = copy(rb)
    sheet1 = book.get_sheet(0)
    # sheet1.write(0, 0, 'changed!')

    lengthList = getRowAndColume(filename)
    nrowsStart = lengthList[0]
    ncols = lengthList[1]

    ListtoBeWtSize = len(psrInfoList)
    for i in xrange(0, ListtoBeWtSize, 1):
        row = sheet1.row(nrowsStart + i)
        for j in range(0, ncols, 1):
            if psrInfoList[i][j] is None:
                row.write(j, '')
            # elif j in (6, 11, 12, 22, 27, 28, 45, 131):
            #    row.write(j, datetime_toString(psrInfoList[i][j]))
            #elif j == 17:
            #    row.write(j, psrInfoList[i][j].decode('gbk'))
            else:
                row.write(j, psrInfoList[i][j])
    for i in range(0, ncols, 1):
        sheet1.col(i).width = 5000
    book.save(filename)


def datetime_toString(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S")


# 2014-03-02
def isToday(datestr):
    if time.strftime("%Y-%m-%d", time.localtime(time.time())) == datestr:
        return True
    else:
        return False


def getRowAndColume(filename):
    data = xlrd.open_workbook(filename)
    table = data.sheets()[0]
    nrows = table.nrows
    ncols = table.ncols

    lengthList = []
    lengthList.append(nrows)
    lengthList.append(ncols)
    return lengthList


def getPsrHisInfoSegName():
    conn = cx_Oracle.connect('apsis/apsis@10.6.184.74/apsisapi')
    cursor = conn.cursor()
    sql = '''select column_name from user_tab_columns where table_name = 'PASSENGER_INFO_HIS_TAB' order by column_id '''
    # print sql
    cursor.execute(sql)
    segNameListTuple = cursor.fetchall()
    segNameList = []
    for item in segNameListTuple:
        # print item[0]
        segNameList.append(item[0])
    return segNameList


def getApsisPartition(date):
    # date in: 2013-11-01
    # expert out: P_201311
    if (dateCheck(date)):
        return 'P_' + date[0:4] + date[5:7]
    else:
        return '000000'


def dateCheck(date):
    y = int(date[0:4])
    m = int(date[5:7])
    d = int(date[8:])

    try:
        datetime.date(y, m, d)
        # print "Date format is True"
        return True
    except:
        # print "Date format is False"
        return False


def main():
    # get101PsrInfo201302('2013-02-26')
    # get101PsrInfo201302('2013-02-27')
    # get101PsrInfo201302('2013-02-28')
    # get101PsrInfo('2014-02-14')
    # get101PsrInfo('2014-02-15')
    # get101PsrInfo('2014-02-18')
    # print isToday("2014-03-02")
    # 1.2014-05-17至21  PEK/SHA/PVG/SZX/CAN/HKG-KUL
    #2.2013-08-01至06  PEK/SHA/PVG/SZX/CAN/HKG-KUL
    getCBMSinfo()


if __name__ == "__main__":
    main()