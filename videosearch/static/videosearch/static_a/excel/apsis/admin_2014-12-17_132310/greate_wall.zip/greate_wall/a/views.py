from django.shortcuts import render
# coding=utf-8
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import Template, Context, RequestContext
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib.auth.models import User
from a.logic_util import get_user_group_context


@login_required
def index(request):
    user_name = request.user.username
    if user_name:
        context = get_user_group_context(user_name)
        return render_to_response('index.html', RequestContext(request, context))
    else:
        return render_to_response('index.html', RequestContext(request))


def logout_view(request):
    logout(request)
    return HttpResponseRedirect("/index/")


# def index(request):
# if ("username" in request.COOKIES):
# # return HttpResponseRedirect("/guide")
# return render_to_response('index.html', RequestContext(request))
# else:
# return render_to_response("a/auth_manage/auth.html", RequestContext(request))


def aboutme(request):
    user_name = request.user.username
    if user_name:
        user_obj = User.objects.filter(username=user_name).all()[0]
        is_super = user_obj.is_superuser

        group_obj = user_obj.groups.all()
        groups = {}
        group_id_list = []
        for grp in group_obj:
            groups["id"] = grp.id
            groups["name"] = grp.name
            group_id_list.append(grp.id)
        context = {'username': user_name, 'group_id_list': group_id_list, 'is_super': is_super}
        return render_to_response('aboutme.html', RequestContext(request, context))
    else:
        return render_to_response('aboutme.html', RequestContext(request))