__author__ = 'Chris'
# coding=utf-8
from django.shortcuts import render_to_response
from django.template import Template, Context, RequestContext
from django.contrib.auth.decorators import login_required

# Create your views here.


@login_required(login_url="/login/")
def self(request):
    return render_to_response("a/guide/guide_page.html", RequestContext(request))


# def self(request):
#     if ("username" in request.COOKIES):
#         return render_to_response("a/guide/guide_page.html", RequestContext(request))
#     else:
#         return render_to_response("a/auth_manage/auth.html", RequestContext(request))