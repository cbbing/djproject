__author__ = 'Chris'
# coding=utf-8
import cx_Oracle
import string
import xlwt
import xlrd
from xlutils.copy import copy
import datetime
import time
from get_psr_info_util import *


def getPsrInfoByCertNoAndDate(cert_no_lst, start_date, end_date, first_line_list, data_line_number_list, filepath):
    # step 1 : Create Excel
    # step 2 : Write Title: first line
    # step 3 : Write data to Excel

    # date format: '2014-07-21'

    conn = cx_Oracle.connect('apsis/apsis@10.6.184.74/apsisapi')
    cursor = conn.cursor()
    countTotal = 0
    countExcel = 0

    cert_no_lst_str = ''
    for item in cert_no_lst:
        cert_no_lst_str += "'" + item + "'" + ","

    cert_no_lst_str = '(' + cert_no_lst_str[:len(cert_no_lst_str) - 1] + ')'

    print cert_no_lst_str

    sql = '''
     select *
  from  passenger_info_his_tab t
 where t.cert_no in  ''' + cert_no_lst_str

    print sql
    cursor.execute(sql)

    FetchNum = 5000
    FetchCount = 0
    result_tmp = []
    fileCount = 1
    fileNowName = 'data-' + u'按证件号和日期查询' + '--' + str(fileCount)
    while True:
        psrInfoListTmp = []
        psrInfoListTmp = cursor.fetchmany(FetchNum)

        # while FetchCount >= 65000 or  FetchCount=0, then create new file
        if FetchCount % 65000 == 0:
            fileCount += 1
            fileNowName = 'data-' + u'按证件号查询' + '--' + start_date + '--' + end_date + '--' + str(FetchCount / 65000)

            writeToExcelFirstLine(filepath + fileNowName + '.xls', first_line_list)
            # while FetchCount < 65000 and FetchCount >0, then go on

        result_tmp = ()
        result_tmp = psrInfoListTmp
        writeToExcelDate1(filepath + fileNowName + '.xls', result_tmp, start_date, end_date, data_line_number_list)

        FetchCount += FetchNum
        print "FetchCount is %d: " % FetchCount

        if len(psrInfoListTmp) < FetchNum:
            totalCount = len(psrInfoListTmp) + FetchCount - FetchNum
            print "TotalCount is %d: " % (totalCount,)
            break
    cursor.close()
    conn.close()
    return


# write psr info per 5000
def writeToExcelFirstLine(filename, first_line_list):
    book = xlwt.Workbook()
    sheet1 = book.add_sheet(u'进港数据')
    # book.add_sheet('word')  #add a

    row1 = sheet1.row(0)
    columnCount = 0

    for item in first_line_list:
        row1.write(columnCount, item)
        columnCount += 1

    for i in range(0, columnCount, 1):
        sheet1.col(i).width = 12000
        # sheet1.col(0).width = 10000

    book.save(filename)


def writeToExcelDate(filename, psrInfoList, start_date, end_date):
    rb = xlrd.open_workbook(filename)
    book = copy(rb)
    sheet1 = book.get_sheet(0)
    # sheet1.write(0, 0, 'changed!')

    lengthList = getRowAndColume(filename)
    nrowsStart = lengthList[0]
    ncols = lengthList[1]

    print "1"

    ListtoBeWtSize = len(psrInfoList)
    for i in range(0, ListtoBeWtSize, 1):
        val1 = 0
        val2 = 0
        try:
            val1 = cmp(datetime_toString(psrInfoList[i][j][:10]), start_date)
            val2 = cmp(datetime_toString(psrInfoList[i][j][:10]), end_date)
        except:
            pass
        if val1 < 0 or val2 > 0:
            continue
        row = sheet1.row(nrowsStart + i)
        print "2"
        for j in range(0, ncols, 1):
            print "3"
            if psrInfoList[i][j] is None:
                row.write(j, '')
            elif j in (6, 11, 12, 22, 27, 28, 45, 131):
                row.write(j, datetime_toString(psrInfoList[i][j]))
            elif j == 17:
                row.write(j, psrInfoList[i][j].decode('gbk'))
            else:
                row.write(j, psrInfoList[i][j])
    for i in range(0, ncols, 1):
        sheet1.col(i).width = 5000
    book.save(filename)


def writeToExcelDate1(filename, psrInfoList, start_date, end_date, data_line_number_list):
    rb = xlrd.open_workbook(filename)
    book = copy(rb)
    sheet1 = book.get_sheet(0)
    # sheet1.write(0, 0, 'changed!')

    lengthList = getRowAndColume(filename)
    nrowsStart = lengthList[0]
    ncols = lengthList[1]

    if ncols != len(data_line_number_list):
        print "error"
        return "ERROR0"

    ListtoBeWtSize = len(psrInfoList)
    print ListtoBeWtSize
    ListOfItem = len(psrInfoList[0])
    for i in range(0, ListtoBeWtSize, 1):
        val1 = 0
        val2 = 0
        try:
            val1 = cmp(datetime_toString(psrInfoList[i][6][:10]), start_date)
            val2 = cmp(datetime_toString(psrInfoList[i][6][:10]), end_date)
        except:
            pass
        if val1 < 0 or val2 > 0:
            continue
        row = sheet1.row(nrowsStart + i)
        list_tmp = []
        for k in range(0, ListOfItem, 1):
            if k in data_line_number_list:
                if psrInfoList[i][k] is None:
                    list_tmp.append('')
                elif k in (6, 11, 12, 22, 27, 28, 45, 131):
                    list_tmp.append(datetime_toString(psrInfoList[i][k]))
                elif k == 17:
                    list_tmp.append(psrInfoList[i][k].decode('gbk'))
                else:
                    list_tmp.append(psrInfoList[i][k])
        for j in range(0, ncols, 1):
            row.write(j, list_tmp[j])
    for i in range(0, ncols, 1):
        sheet1.col(i).width = 3000
    book.save(filename)


if __name__ == '__main__':
    data_item_list_less = [u'ID', u'航班ID', u'航空公司', u'航班号', u'航班日期', u'出发机场',
                           u'到达机场', u'姓名', u'中文名', u'姓', u'名', u'出生日期', u'证件号码']
    data_number_list = [0, 2, 3, 4, 9, 10, 16, 17, 18, 20, 22, 26]
    print len(data_item_list_less)
    print len(data_number_list)
    print getPsrInfoByCertNoAndDate(['522229199408280084'], '2013-01-01', '2014-11-11',
                                    data_item_list_less, [0, 2, 3, 4, 6, 9, 10, 16, 17, 18, 20, 22, 26], 'F:/')

'''
 data_item_list_less = ['ID', '航班ID', '航空公司', '航班号', '航班日期', '出发机场',
                               '到达机场', '姓名', '中文名', '姓', '名', '出生日期', '证件号码']

'''