__author__ = 'Chris'

import time


def get_current_time_str():
    return time.strftime('%Y-%m-%d_%H%M%S', time.localtime(time.time()))


def test():
    timestr = get_current_time_str()
    return 'static_a/excel/data_%s.xls' % timestr


if __name__ == '__main__':
    print get_current_time_str()
    print test()