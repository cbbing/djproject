from django.conf.urls import patterns, url
from a.apsis import views

urlpatterns = patterns('a.apsis.views',
                       url(r'^$', views.self, name='self'),
                       url(r'^apsis_index$', views.apsis_index, name='apsis_index'),
                       url(r'^apsis_query$', views.apsis_query, name='apsis_query'),
                       url(r'^apsis_query_quick/$', views.apsis_query_quick, name='apsis_query_quick'),

                       # url(r'^apsis_users', views.apsis_users, name='apsis_users'),
                       # url(r'^apsis_api_send_flag', views.apsis_api_send_flag, name='apsis_api_send_flag'),
                       # url(r'^apsis_rsv_send_flag', views.apsis_rsv_send_flag, name='apsis_rsv_send_flag'),


                       # url(r'^self$', views.self, name='self'),
                       # url(r'^result$', views.result, name='result'),
                       # url(r'^check$', views.check, name='check'),
)